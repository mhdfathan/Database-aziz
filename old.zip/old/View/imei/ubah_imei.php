<?php

include ("controller/mengedit_data.php");

?>

<div class="panel panel-primary">
<div class="panel-heading">
    <font size="3">
		Form Ubah Data IMEI
    </font>
</div>
<div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <form role="form" method="POST">
                                        <div class="form-group">
                                            <label>Nama Karyawan</label>
                                            <input class="form-control" name="nama" value="<?php echo $tampil['nama'];?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Department</label>
                                            <select class="form-control" name="department" required>
                                                <option value="IT Operation" <?php if ($department=='IT Operation') {echo "selected";}?>>IT Operation</option>
                                                <option value="Inbound" <?php if ($department=='Inbound') {echo "selected";}?>>Inbound</option>
                                                <option value="Outbound" <?php if ($department=='Outbound') {echo "selected";}?>>Outbound</option>
                                                <option value="Inventory" <?php if ($department=='Inventory') {echo "selected";}?>>Inventory</option>
                                                <option value="Quarantine and Return" <?php if ($department=='Quarantine and Return') {echo "selected";}?>>Quarantine and Return</option>
                                                <option value="Project Team" <?php if ($department=='Project Team') {echo "selected";}?>>Project Team</option>
                                                <option value="Management" <?php if ($department=='Management') {echo "selected";}?>>Management</option>
                                            </select>

                                        </div>

                                        <div class="form-group">
                                            <label>ID Perangkat</label>
                                            <input class="form-control" name="id_perangkat" value="<?php echo $tampil['id_perangkat'];?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Jenis Perangkat</label>
                                            <input class="form-control" name="jenis_perangkat" value="<?php echo $tampil['jenis_perangkat'];?>" required>
                                        </div>
                                        <div>
                                        	
                                        <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                                        </div>
                                    </form>
                                </div>
                            </div>
</div>
</div>

<?php

include ("controller/proses_edit_data.php");

?>