<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <font size="3">
                            Database IMEI
                            </font>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th><div align="center"> No </div></th>
                                            <th><div align="center">Nama Karyawan</div></th>
                                            <th><div align="center">Department</div></th>
                                            <th><div align="center">ID Perangkat</div></th>
                                            <th><div align="center">Jenis Perangkat</div></th>
                                            <th><div align="center">Aksi</div></th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <!--Script Menampilkan Database pada Program-->
                                    <?php
                                        $no=1;
                                        include ("model/koneksi.php");
                                            $sql = mysqli_query($koneksi,"SELECT * FROM tb_imei");
                                        while ($data = mysqli_fetch_assoc($sql)) {
                                    ?>

                                        <tr>
                                            <td><div align="center"><?php echo $no++;?></div></td>
                                            <td><?php echo $data['nama'];?></td>
                                            <td><?php echo $data['department'];?></td>
                                            <td><?php echo $data['id_perangkat'];?></td>
                                            <td><?php echo $data['jenis_perangkat'];?></td>
                                            <td>
                                            <!--Script Tombol Edit-->
                                            <div align="center">
                                            <a href="?page=imei&aksi=ubah&id=<?php echo $data ['id'];?>" class="btn btn-info"><i class="fa fa-edit"></i> Edit</a>
                                            <a onclick="return confirm('Data akan di hapus?')" href="?page=imei&aksi=hapus&id=<?php echo $data ['id'];?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                            </div>
                                            </td>
                                        </tr>

                                        <?php 
                                        
                                        }
                                        mysqli_close($koneksi); 
                                        ?>
                                    </tbody>

                                </table>

                            </div>
                    </div>
                </div>
            </div>