<div class="panel panel-primary">
<div class="panel-heading">
    <font size="3">
		Form Tambah Data IMEI
    </font>
</div>
<div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <form role="form" method="POST">
                                        <div class="form-group">
                                            <label>Nama Karyawan</label>
                                            <input class="form-control" name="nama" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Department</label>
                                            <select class="form-control" name="department" required>
                                                <option value="IT Operation">IT Operation</option>
                                                <option value="Inbound">Inbound</option>
                                                <option value="Outbound">Outbound</option>
                                                <option value="Inventory">Inventory</option>
                                                <option value="Quarantine and Return">Quarantine and Return</option>
                                                <option value="Project Team">Project Team</option>
                                                <option value="Management">Management</option>
                                            </select>

                                        </div>

                                        <div class="form-group">
                                            <label>ID Perangkat</label>
                                            <input class="form-control" name="id_perangkat" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Jenis Perangkat</label>
                                            <input class="form-control" name="jenis_perangkat" required>
                                        </div>
                                        <div>
                                        	
                                        <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                                        </div>
                                    </form>
                                </div>
                            </div>
</div>
</div>

<?php

include ("controller/simpan_form.php");

?>