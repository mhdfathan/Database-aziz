<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "db_imei";
$koneksi = mysqli_connect($hostname, $username, $password, $database);

if ($koneksi) {
   mysqli_select_db($koneksi,$database) or die ("Database Tidak Ditemukan");
} else 
{
   die(mysql_error());
}
?>