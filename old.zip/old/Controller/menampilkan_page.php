<?php
error_reporting(0);
    $page = ($_GET['page']);
    $aksi = ($_GET['aksi']);
        if ($page == "imei") {
        if ($aksi == "") {
            include "view/imei/imei.php";
            }
        if ($aksi == "tambah") {
            include "view/imei/tambah_imei.php";
            }
        if ($aksi == "ubah") {
            include "view/imei/ubah_imei.php";    
            }
        if ($aksi == "hapus") {
            include "controller/hapus_imei.php";    
            }
    }
?>