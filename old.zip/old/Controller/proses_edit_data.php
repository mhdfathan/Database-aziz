<!--Script Tombol Simpan-->
<?php

include ("model/koneksi.php");

if(isset($_POST['simpan'])) {

$nama = $_POST ['nama'];
$department = $_POST ['department'];
$idperangkat = $_POST ['id_perangkat'];
$jenisperangkat = $_POST ['jenis_perangkat'];

	$query = "update tb_imei set nama='$nama', department='$department', id_perangkat='$idperangkat', jenis_perangkat='$jenisperangkat' where id='$id'";
	$input = mysqli_query ($koneksi, $query);
	
	if ($input) {
?>

<!--Script Kembali ke Data Imei-->
		<script type="text/javascript">
		alert ("Data Berhasil Diedit");
		window.location.href="?page=imei";
		</script>
		
		<?php
		}	
	}
?>