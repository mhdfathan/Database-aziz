<!--Script Tombol Simpan-->
<?php

include ("model/koneksi.php");

if(isset($_POST['simpan'])) {

$nama = $_POST ['nama'];
$department = $_POST ['department'];
$idperangkat = $_POST ['id_perangkat'];
$jenisperangkat = $_POST ['jenis_perangkat'];


	$input = mysqli_query ($koneksi, "INSERT INTO tb_imei VALUES ('NULL','$nama', '$department', '$idperangkat', '$jenisperangkat')");

	
	if ($input) {
mysqli_close($koneksi);
?>

<!--Script Kembali ke Data Imei-->
		<script type="text/javascript">
		alert ("Data Berhasil Disimpan");
		window.location.href="?page=imei";
		</script>
		
		<?php
	}

}
?>