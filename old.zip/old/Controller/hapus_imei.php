<?php

include ("model/koneksi.php");
	$id = $_GET ['id'];
	mysqli_query($koneksi, "delete from tb_imei where id='$id'");

	mysqli_close($koneksi);
?>

<script type="text/javascript">
	window.location.href="?page=imei";
</script>