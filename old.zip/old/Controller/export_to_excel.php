<?php

	$filename = "Database_IMEI-(".date('d-m-y').").xls";

	header("content-disposition: attachment; filename=$filename");
	header("content-type: application/vdn.ms-excel");

?>
<table border="1">
<tr>
		<th><div align="center">No</div></th>
		<th>Nama Karyawan</th>
        <th>Department</th>
        <th>ID Perangkat</th>
        <th>Jenis Perangkat</th>
</tr>	

									<?php
                                        $no=1;
                                    	    
                                        	$hostname = "localhost";
											$username = "root";
											$password = "";
											$database = "db_imei";
											$koneksi = mysqli_connect($hostname, $username, $password, $database);
												if ($koneksi) {
											   		mysqli_select_db($koneksi,$database) or die ("Database Tidak Ditemukan");
												} else 
													{
											   	die(mysql_error());
													}
                                            	$sql = mysqli_query($koneksi,"SELECT * FROM tb_imei");
                                        			while ($data = mysqli_fetch_assoc($sql)) {
                                    ?>
                                    	<tr>
                                            <td><div align="center"><?php echo $no++;?></div></td>
                                            <td><?php echo $data['nama'];?></td>
                                            <td><?php echo $data['department'];?></td>
                                            <td><div align="left"><?php echo $data['id_perangkat'];?></div></td>
                                            <td><?php echo $data['jenis_perangkat'];?></td>
                                        </tr> 
                                   <?php
									}
                                   ?>
</table>