<?php

include ("model/koneksi.php");

	$id = $_GET['id'];
	$sql = mysqli_query ($koneksi,"select * from tb_imei where id='$id'");
	$tampil = mysqli_fetch_assoc($sql);
	$department = $tampil['department'];

mysqli_close($koneksi);

?>